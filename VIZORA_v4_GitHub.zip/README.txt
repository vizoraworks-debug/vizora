VIZORA v4 — FREE GITHUB PAGES VERSION

Upload index.html and vizora-cover.webp to your existing GitHub repository and commit the changes.

The site is static and GitHub Pages compatible.
Project Upload / Reel Posting buttons use the supplied Google Form:
https://docs.google.com/forms/d/e/1FAIpQLSckS-vD4_tKwZ16H2ZD_HJunKsYuliLuX4oCs3NybOtLSbk8w/viewform?usp=dialog

Instagram: https://www.instagram.com/vizora.works/
YouTube: https://youtube.com/@vizoraworks
WhatsApp: +91 75106 56149
Email: vizoraworks@gmail.com

Facebook and Threads removed.
